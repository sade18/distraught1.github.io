You can use this directory if you are developing a plugin but don't want it to be picked up by git quite yet.  All plugins in this directory will be loaded by Interactive Linter.
